import json


data = 'data.json'
student = input('student full name: ')
new = input('new student? (y/n): ')



def create_school_user():
    student_id = input("student's new id: ")

    with open(data, 'r') as f:
        j = json.load(f)
        j[student] = {'full name': student, "id": student_id, '-----': '-----'}
        with open(data, 'w') as b:
            json.dump(j, b, indent=4)

        print('success')



def add_grade():
    assignment = input('assignment name: ')
    grade = input('grade: ')

    with open(data, 'r') as f:
        j = json.load(f)
        j[student].update({f'{assignment}': grade})
        with open(data, 'w') as b:
            json.dump(j, b, indent=4)

        print('successfully added grade')


if new == 'y':
    create_school_user()
elif new == 'n':
    add_grade()
else:
    print("invalid character for prompt")
